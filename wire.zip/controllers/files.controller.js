const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const { findFolderById } = require('../services/file.service');
const { getUserFolders, getFolderAccess } = require('../services/share.service');
const { safeSubPath } = require('../utils/safePath');
const { getMimeType, moveFileSafe } = require('../utils/file');

function validateFolderId(value) {
  const id = Number(value);
  return Number.isInteger(id) ? id : null;
}

function getFolders(req, res) {
  const folders = getUserFolders(req.user.id);
  res.json(
    folders.map(folder => ({
      id: folder.id,
      display_name: folder.display_name,
      can_write: !!folder.can_write,
    }))
  );
}

function getFolderAndAccess(userId, folderId) {
  const folder = findFolderById(folderId);
  if (!folder) return { error: 'Folder not found' };

  const access = getFolderAccess(userId, folderId);
  if (!access) return { error: 'Access denied' };

  return { folder, access };
}

// listFiles used to be built entirely on the *Sync fs APIs
// (readdirSync + one statSync per entry). Each of those blocks
// Node's single event loop thread for the syscall's duration, and
// the statSync loop in particular scales with the number of entries
// in the folder — a big "Drive"-style folder with thousands of
// files could stall every other in-flight request (chat, other
// downloads, everything) for as long as it takes to stat all of
// them, one at a time.
//
// This does the same two syscalls (readdir, stat) but through
// fs/promises, so each individual call yields to the event loop
// instead of blocking it. Per-entry stats are resolved with bounded
// concurrency (STAT_CONCURRENCY at a time) rather than either fully
// serial (slow) or fully parallel (a folder with 10,000 files would
// otherwise fire 10,000 simultaneous stat() syscalls / open file
// descriptors at once). The response shape, sorting, dotfile
// filtering, and error behavior are unchanged from the sync version.
const STAT_CONCURRENCY = 32;

async function statEntriesLimited(dirents, dirPath) {
  const results = new Array(dirents.length);
  let cursor = 0;

  async function worker() {
    while (cursor < dirents.length) {
      const i = cursor++;
      const dirent = dirents[i];
      const full = path.join(dirPath, dirent.name);
      const stat = await fsp.stat(full);
      results[i] = {
        name: dirent.name,
        type: dirent.isDirectory() ? 'dir' : 'file',
        size: stat.size,
        modified: stat.mtime.toISOString(),
      };
    }
  }

  const workers = Array.from(
    { length: Math.min(STAT_CONCURRENCY, dirents.length) },
    worker
  );
  await Promise.all(workers);

  return results;
}

async function pathExists(p) {
  try {
    await fsp.access(p);
    return true;
  } catch {
    return false;
  }
}

async function listFiles(req, res) {
  const folderId = validateFolderId(req.params.folderId);
  if (!folderId) return res.status(400).json({ error: 'Invalid folder id' });

  const result = getFolderAndAccess(req.user.id, folderId);
  if (result.error) return res.status(403).json({ error: result.error });

  const subpath = req.query.subpath || '';
  const target = safeSubPath(result.folder.path, subpath);

  try {
    if (!target) {
      return res.status(404).json({ error: 'Path not found' });
    }

    const targetStat = await fsp.stat(target).catch((err) => {
      if (err.code === 'ENOENT') return null;
      throw err;
    });

    if (!targetStat) {
      return res.status(404).json({ error: 'Path not found' });
    }
    if (!targetStat.isDirectory()) {
      return res.status(400).json({ error: 'Not a directory' });
    }

    const dirents = (await fsp.readdir(target, { withFileTypes: true }))
      .filter(x => !x.name.startsWith('.'));

    const entries = await statEntriesLimited(dirents, target);

    res.json({ subpath, entries, can_write: !!result.access.can_write });

  } catch (err) {
    console.error('listFiles failed:', err.message);
    res.status(500).json({ error: 'Failed to list folder contents' });
  }
}

function uploadFile(req, res) {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const cleanupTemp = () => fs.unlink(req.file.path, () => {});

  const folderId = validateFolderId(req.params.folderId);
  if (!folderId) {
    cleanupTemp();
    return res.status(400).json({ error: 'Invalid folder id' });
  }

  const result = getFolderAndAccess(req.user.id, folderId);
  if (result.error || !result.access.can_write) {
    cleanupTemp();
    return res.status(403).json({ error: 'Write access denied' });
  }

  const subpath = req.body.subpath || '';
  const dir = safeSubPath(result.folder.path, subpath);
  if (!dir || !fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
    cleanupTemp();
    return res.status(404).json({ error: 'Destination folder not found' });
  }

  let name = path.basename(req.file.originalname);
  let finalPath = path.join(dir, name);
  let count = 1;
  while (fs.existsSync(finalPath)) {
    const ext = path.extname(name);
    const base = path.basename(name, ext);
    name = `${base} (${count})${ext}`;
    finalPath = path.join(dir, name);
    count++;
  }

  try {
    moveFileSafe(req.file.path, finalPath);
  } catch (err) {
    console.error('File upload failed to move into place:', err.message);
    cleanupTemp();
    return res.status(500).json({ error: 'Failed to save the uploaded file' });
  }

  res.json({ success: true, name });
}

// ============ اضافه شده: downloadFile ============
function downloadFile(req, res) {
  const folderId = validateFolderId(req.params.folderId);
  if (!folderId) return res.status(400).json({ error: 'Invalid folder id' });

  const result = getFolderAndAccess(req.user.id, folderId);
  if (result.error) return res.status(403).json({ error: result.error });

  const subpath = req.query.subpath || '';
  const file = req.query.file; // نام فایل
  if (!file) return res.status(400).json({ error: 'File parameter missing' });

  const target = safeSubPath(result.folder.path, subpath);
  if (!target || !fs.existsSync(target)) {
    return res.status(404).json({ error: 'Path not found' });
  }
  if (!fs.statSync(target).isDirectory()) {
    return res.status(400).json({ error: 'Not a directory' });
  }

  const resolved = safeSubPath(target, file);
  if (!resolved || !fs.existsSync(resolved)) {
    return res.status(404).json({ error: 'File not found' });
  }

  res.download(resolved, file);
}

// ============ اضافه شده: previewFile ============
function previewFile(req, res) {
  const folderId = validateFolderId(req.params.folderId);
  if (!folderId) return res.status(400).json({ error: 'Invalid folder id' });

  const result = getFolderAndAccess(req.user.id, folderId);
  if (result.error) return res.status(403).json({ error: result.error });

  const subpath = req.query.subpath || '';
  const file = req.query.file;
  if (!file) return res.status(400).json({ error: 'File parameter missing' });

  const target = safeSubPath(result.folder.path, subpath);
  if (!target || !fs.existsSync(target)) {
    return res.status(404).json({ error: 'Path not found' });
  }
  if (!fs.statSync(target).isDirectory()) {
    return res.status(400).json({ error: 'Not a directory' });
  }

  const resolved = safeSubPath(target, file);
  if (!resolved || !fs.existsSync(resolved)) {
    return res.status(404).json({ error: 'File not found' });
  }

  const mime = getMimeType(resolved); // تابع تشخیص mime که از utils/file گرفته می‌شود
  res.setHeader('Content-Type', mime);
  res.sendFile(resolved);
}

module.exports = {
  getFolders,
  listFiles,
  downloadFile,
  previewFile,
  uploadFile,
};